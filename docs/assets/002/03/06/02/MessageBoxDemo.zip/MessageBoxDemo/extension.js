var vscode = require('vscode');
function activate(context) {

	var sayHello = vscode.commands.registerCommand('extension.showMessageBox', function () {

		/////////////////演示普通消息框/////////////////
		// vscode.window.showInformationMessage('这是普通消息框吗？', '是', '否').then(function (msg) {
		// 	console.log(msg);
		// 	if (msg === '是') {
		// 		console.log('输出：是');
		// 	}

		// 	if (msg === '否') {
		// 		console.log('输出：否');
		// 	}

		// 	if (msg === undefined) {
		// 		console.log('输出：undefined');
		// 	}
		// });


		/////////////////演示警告消息框/////////////////
		// vscode.window.showWarningMessage('这是警告消息框吗？，如果是，请点击“确定”','确定','取消').then(function(msg){
		// 	if(msg === '确定')
		// 	{
		// 		console.log('你选中了“确定”哦');
		// 	}else{
		// 		console.log('你没有选中“确定”');
		// 	}
		// });


		/////////////////演示错误消息框/////////////////
		// vscode.window.showErrorMessage('目前正常运行的条件并不满足，是否继续往下执行？','继续','取消').then(function(msg){
		// 	if(msg === '继续')
		// 	{
		// 		console.log('往下执行');
		// 	}else{
		// 		console.log('终止执行');
		// 	}
		// });


		/////////////////演示下拉列表框/////////////////
		var languages = vscode.languages.getLanguages();
		vscode.window.showQuickPick(languages).then(function(msg)
		{
			console.log('当前用户选择了：'+msg+'语言');
		});	

		/////////////////演示用户输入框/////////////////
		// vscode.window.showInputBox({placeHolder: '请输入密码',password: true }).then(function(msg)
		// {
		// 	console.log('当前用户输入的信息为：'+msg);
		// });

		// vscode.window.showInputBox({placeHolder: '请输入阈值', value: '10000',ignoreFocusOut: true  }).then(function(msg)
		// {
		// 	console.log('当前用户输入的信息为：'+msg);
		// });

	});
	context.subscriptions.push(sayHello);
}
exports.activate = activate;


/////////////////////////FAQ解答/////////////////////////
/**
 var vscode = require('vscode');
function activate(context) {
	
	var sayHello = vscode.commands.registerCommand('extension.showMessageBox', function () {

		//判断文件夹是否为非空，假设此文件夹非空，则先清空此文件夹再执行
		//文件拷贝操作
		if (!isNullFolder()) {
			vscode.window.showWarningMessage('当前文件夹是非空的，是否清空此文件夹，然后在执行文件拷贝？', '清空', '不处理').then(function (msg) {
				console.log('用户选择的操作是：'+msg);
				if (msg === '清空') {
					clearFolder();
				}
			});
		}

		//执行文件拷贝操作
		copyToSpecialFolder();

	});
	context.subscriptions.push(sayHello);
}
exports.activate = activate;

function isNullFolder() {
	return false;//假设文件夹非空
	// return true;//假设文件夹为空
}

function clearFolder() {
	console.log('执行清空文件夹操作');
}

function copyToSpecialFolder() {
	console.log('执行文件拷贝操作');
}

 */