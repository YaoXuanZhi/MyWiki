var vscode = require('vscode');

function activate(context) {
	var sayHello = vscode.commands.registerCommand('extension.sayHello', function () {
		vscode.window.showInformationMessage('Hello World!');
	});
	var EditorContextProc = vscode.commands.registerCommand('extension.editor_context', function () {
		vscode.window.showInformationMessage('响应文档编辑器上的右键菜单点击事件');
	});
	var EditorTitleProc = vscode.commands.registerCommand('extension.editor_title', function () {
		vscode.window.showInformationMessage('响应文档编辑器上的标题菜单项点击事件');
	});
	var ExplorerTitileProc = vscode.commands.registerCommand('extension.explorer_context', function () {
		vscode.window.showInformationMessage('响应资源管理器上的弹出菜单点击事件');
	});
	context.subscriptions.push(sayHello);
	context.subscriptions.push(EditorContextProc);
	context.subscriptions.push(EditorTitleProc);
	context.subscriptions.push(ExplorerTitileProc);
}
exports.activate = activate;