# 请阅读Me!

>此VS Code Extension只要演示了一个单词统计的Demo，在这里，我将一些VS Code extension开发常用的API简单地演示了一番，主要是如何响应各种VS Code界面元素的各种回调函数的响应和一般的操作方式。