﻿//var win=new Window("dialog","GetLayerName（Window）");
//var win=new Window("window","GetLayerName（Window）");
var win=new Window("palette","GetLayerName（Window）");
var MyButton=win.add("Button",undefined,"GetLayerName");
win.show();

MyButton.onClick=function()
{
    RunCommand();
    
    }





function RunCommand()
{
//		alert("Creating dummy project, app version=" + app.version);
//		alert("done");
var SelLayer=app.project.activeItem.selectedLayers[0];
if(SelLayer)
{
alert(SelLayer.name);    
    }
else {alert("请选中一个图层");}

    
    }