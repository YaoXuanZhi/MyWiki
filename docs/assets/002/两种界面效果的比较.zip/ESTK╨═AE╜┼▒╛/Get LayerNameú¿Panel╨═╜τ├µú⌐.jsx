﻿function BuildUI(OBJ)
{
var win =OBJ;
var MyButton=win.add("Button",undefined,"GetLayerName");
win.layout.layout(true);//调用布局管理器刷新界面，否则将会无法显示控件

MyButton.onClick=function()
{
    RunCommand();
    
    }
return win;
}//function BuildUI(OBJ)

BuildUI (this);



/***********************************************下面自定义子函数**************************************/

function RunCommand()
{
//		alert("Creating dummy project, app version=" + app.version);
//		alert("done");
var SelLayer=app.project.activeItem.selectedLayers[0];
if(SelLayer)
{
alert(SelLayer.name);    
    }
else {alert("请选中一个图层");}

    
    }