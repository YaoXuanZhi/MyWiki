package.path = package.path .. ";e:/bin/?.lua";
package.path = package.path .. ";e:/bin/scripts";require("LuaDebug")("localhost", 7003)
require("main")